    import styled from 'styled-components';

   export const StyledButton = styled.button`
      background-color: blue;
      color: red;
      padding: 10px 20px;
      border-radius: 5px;
      &:hover {
        background-color: darkblue;
      }
    `;


    export const StyledDiv = styled.div`
      background-color: red;
      color: black;
      padding: 10px 20px;
      border-radius: 5px;
      &:hover {
        background-color: darkblue;
      }
    `;