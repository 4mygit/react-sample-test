import { useState } from "react";

import { useSelector, useDispatch } from 'react-redux';
import { allActions } from './store/';


export default function CounterStatus(){
 
      const dispatch = useDispatch();

      const {increment} = allActions
    //let counter = 2;
    //let [counter, setCounter] = useState(2);


  const counter = useSelector((state) =>     state.counter__MayBachRacingCar.value);
  const userid = useSelector((state) =>     state.userid);

   const handleIncrement = () => {
    dispatch(increment());
  };

 return(
<>
<h1>Counter Value</h1>{counter}
<p>
<button onClick={handleIncrement}>Click</button>
<p>Counter: {userid}</p>
<p>Counter: {counter}</p>
</p>
</>

 )
}

