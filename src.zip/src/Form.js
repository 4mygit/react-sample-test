import React, { useState } from 'react';

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
    gender: '',
    subscribe: false,
    country: '',
    interests: []
  });

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (type === 'checkbox') {
      if (name === 'interests') {
        // For multiple checkboxes
        const updatedInterests = checked
          ? [...formData.interests, value]
          : formData.interests.filter(interest => interest !== value);
        setFormData(prev => ({ ...prev, interests: updatedInterests }));
      } else {
        // For single checkbox
        setFormData(prev => ({ ...prev, [name]: checked }));
      }
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      // Simulate API call
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (true) {
        console.log(formData)
        alert(JSON.stringify(formData))
        alert('Form submitted successfully!');
        // Reset form
        setFormData({
          name: '',
          email: '',
          message: '',
          gender: '',
          subscribe: false,
          country: '',
          interests: []
        });
      } else {
        alert('Error submitting form');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error submitting form');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="form-container">
      <h2>Contact Form</h2>
      
      {/* Text Input */}
      <div className="form-group">
        <label htmlFor="name">Name:</label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
          required
        />
      </div>

      {/* Email Input */}
      <div className="form-group">
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          required
        />
      </div>

      {/* Textarea */}
      <div className="form-group">
        <label htmlFor="message">Message:</label>
        <textarea
          id="message"
          name="message"
          value={formData.message}
          onChange={handleInputChange}
          rows="4"
          required
        />
      </div>

      {/* Radio Buttons */}
      <div className="form-group">
        <label>Gender:</label>
        <div className="radio-group">
          <label>
            <input
              type="radio"
              name="gender"
              value="male"
              checked={formData.gender === 'male'}
              onChange={handleInputChange}
            />
            Male
          </label>
          <label>
            <input
              type="radio"
              name="gender"
              value="female"
              checked={formData.gender === 'female'}
              onChange={handleInputChange}
            />
            Female
          </label>
          <label>
            <input
              type="radio"
              name="gender"
              value="other"
              checked={formData.gender === 'other'}
              onChange={handleInputChange}
            />
            Other
          </label>
        </div>
      </div>

      {/* Select Dropdown */}
      <div className="form-group">
        <label htmlFor="country">Country:</label>
        <select
          id="country"
          name="country"
          value={formData.country}
          onChange={handleInputChange}
        >
          <option value="">Select Country</option>
          <option value="us">United States</option>
          <option value="ca">Canada</option>
          <option value="uk">United Kingdom</option>
          <option value="au">Australia</option>
        </select>
      </div>

      {/* Checkbox */}
      <div className="form-group">
        <label>
          <input
            type="checkbox"
            name="subscribe"
            checked={formData.subscribe}
            onChange={handleInputChange}
          />
          Subscribe to newsletter
        </label>
      </div>

      {/* Multiple Checkboxes */}
      <div className="form-group">
        <label>Interests:</label>
        <div className="checkbox-group">
          <label>
            <input
              type="checkbox"
              name="interests"
              value="technology"
              checked={formData.interests.includes('technology')}
              onChange={handleInputChange}
            />
            Technology
          </label>
          <label>
            <input
              type="checkbox"
              name="interests"
              value="sports"
              checked={formData.interests.includes('sports')}
              onChange={handleInputChange}
            />
            Sports
          </label>
          <label>
            <input
              type="checkbox"
              name="interests"
              value="music"
              checked={formData.interests.includes('music')}
              onChange={handleInputChange}
            />
            Music
          </label>
        </div>
      </div>

      <button type="submit" className="submit-btn">
        Submit Form
      </button>
    </form>
  );
};

export default ContactForm;