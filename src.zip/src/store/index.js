import { configureStore } from '@reduxjs/toolkit';
//import counterSlice  from './slices/counterSlice';
import { createSlice } from '@reduxjs/toolkit';



const counterSlice = createSlice({
  name: 'counter',
  initialState: {
    value: 0,
    history: [],
  },
  reducers: {
    increment: (state) => {
      state.value += 1;
      state.history.push(`Incremented to ${state.value}`);
    },
    decrement: (state) => {
      state.value -= 1;
      state.history.push(`Decremented to ${state.value}`);
    },
    incrementByAmount: (state, action) => {
      state.value += action.payload;
      state.history.push(`Added ${action.payload} to ${state.value}`);
    },
    reset: (state) => {
      state.value = 0;
      state.history.push('Reset to 0');
    },
    clearHistory: (state) => {
      state.history = [];
    },
  },
});

const userid = createSlice({
  name: 'user',
  initialState: 'hacker', // ❗ Can be a primitive directly!
  reducers: {
    increment: (state) => state + 1,
    decrement: (state) => state - 1,
    setCount: (state, action) => action.payload
  }
});

//console.log(counterSlice.actions)

export const allActions = counterSlice.actions



export const store = configureStore({
  reducer: {
    counter__MayBachRacingCar: counterSlice.reducer,
    //userid: userid.reducer
  },
});


//export default store;
