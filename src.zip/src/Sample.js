import React, {useContext} from "react"


import Samplechild from './Samplechild'; // Assuming you exported StyledButton
import Testcontext from "./TestContext"


export default function Sample({street, city}){

    const ct= useContext(Testcontext)
    ct.isLoggedIn = "Rain shower"


    return(

        <>
        <h1>{street}</h1>

        <h1>{city}</h1>

        <Samplechild/>

        </>
    )
}