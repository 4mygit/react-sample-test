import React, {useContext} from "react"
import Testcontext from "./TestContext"

export default function Samplechild({street, city}){

    const ctx = useContext(Testcontext)
    //ctx.isLoggedIn = "Bulbul"

    return(

        <>
        <h1>This is sample child</h1>
        <h1>{ctx.isLoggedIn}</h1>



        </>
    )
}