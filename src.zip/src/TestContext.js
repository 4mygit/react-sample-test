import React from "react";

const Testcontext = React.createContext({
    isLoggedIn: false

});

export default Testcontext;

